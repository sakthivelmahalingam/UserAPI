package com.boltzmann.utils;

import java.io.PrintWriter;
import java.io.StringWriter;
import org.apache.log4j.Logger;

public class LoggerUtils {

     private static final Logger authenticationLogger = Logger.getLogger("FA");

    public static void logAuthenticationDetails(String message) {
        authenticationLogger.info(message);
    }

    public static void loggerInfo(String message) {
        authenticationLogger.info(message);
    }

    public static void loggerDebug(String message) {
        authenticationLogger.debug(message);
    }

    public static void loggerWarn(String message) {
        authenticationLogger.warn(message);
    }

    public static void loggerTrace(String message) {
        authenticationLogger.trace(message);
    }
    // To print e.printStackTrace in log file    

    public static void loggerError(Exception e) {
        StringWriter stack = new StringWriter();
        e.printStackTrace(new PrintWriter(stack));
        authenticationLogger.error(stack.toString());
    }

    public static void loggerError(String message) {
        authenticationLogger.error(message);
    }
    private static final Logger authenticationFELogger = Logger.getLogger("RFA");

    public static void logAuthenticationFEDetails(String message) {
        authenticationFELogger.info(message);
    }

    public static void loggerFEInfo(String message) {
        authenticationFELogger.info(message);
    }

    public static void loggerFEDebug(String message) {
        authenticationFELogger.debug(message);
    }

    public static void loggerFEWarn(String message) {
        authenticationFELogger.warn(message);
    }
    // To print e.printStackTrace in log file    

    public static void loggerFEError(Exception e) {
        StringWriter stack = new StringWriter();
        e.printStackTrace(new PrintWriter(stack));
        authenticationFELogger.error(stack.toString());
    }

    public static void loggerFEError(String message) {
        authenticationFELogger.error(message);
    }
}
